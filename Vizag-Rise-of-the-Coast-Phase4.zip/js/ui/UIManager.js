import {HUD} from "./HUD.js";
export class UIManager{
 constructor(game){this.game=game;this.hud=new HUD(game)}
 showHUD(){this.hud.show()}
 setHealth(v){this.hud.setHealth(v)} setStamina(v){this.hud.setStamina(v)} setMoney(v){this.hud.setMoney(v)}
 setMission(v){this.hud.setMission(v)} setZone(v){this.hud.setZone(v)} setWanted(v){this.hud.setWanted(v)} setVehicle(v){this.hud.setVehicle(v)} setVehicleTelemetry(s,f){this.hud.setVehicleTelemetry(s,f)}
 setTime(v){this.hud.setTime(v)} setWeather(v){this.hud.setWeather(v)} interaction(v){this.hud.interaction(v)} toast(v){this.hud.toast(v)}
 togglePanel(id,show){document.getElementById(id).classList.toggle("hidden",!show)}
 toggleMap(show){document.getElementById("map-panel").classList.toggle("hidden",!show);if(show)this.game.map.draw()}
 bind(){document.querySelectorAll(".close-panel").forEach(b=>b.onclick=()=>b.closest(".panel").classList.add("hidden"));document.getElementById("resume-btn").onclick=()=>this.pause(false);document.getElementById("save-btn").onclick=()=>{this.game.save();this.toast("GAME SAVED")};document.getElementById("pause-map-btn").onclick=()=>this.toggleMap(true);document.getElementById("pause-settings-btn").onclick=()=>this.togglePanel("settings-panel",true);document.getElementById("exit-btn").onclick=()=>this.game.exitToTitle()}
 pause(show){this.togglePanel("pause-panel",show);this.game.paused=show}
}