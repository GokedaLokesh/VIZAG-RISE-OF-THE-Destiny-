export class SaveSystem{
  static key="vizag-rise-save-v1";
  static save(state){try{localStorage.setItem(this.key,JSON.stringify(state));return true}catch(e){console.warn(e);return false}}
  static load(){try{const x=localStorage.getItem(this.key);return x?JSON.parse(x):null}catch(e){console.warn(e);return null}}
  static clear(){localStorage.removeItem(this.key)}
}