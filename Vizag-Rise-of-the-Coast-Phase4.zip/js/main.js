import * as THREE from "three";
import {AssetManager} from "./core/AssetManager.js";
import {GameLoop} from "./core/GameLoop.js";
import {SaveSystem} from "./core/SaveSystem.js";
import {Terrain} from "./world/Terrain.js";
import {Ocean} from "./world/Ocean.js";
import {Roads} from "./world/Roads.js";
import {Buildings} from "./world/Buildings.js";
import {WorldStreaming} from "./world/WorldStreaming.js";
import {Player} from "./player/Player.js";
import {PlayerController} from "./player/PlayerController.js";
import {CameraController} from "./player/CameraController.js";
import {Vehicle} from "./vehicles/Vehicle.js";
import {TrafficAI} from "./vehicles/TrafficAI.js";
import {NPCManager} from "./npc/NPCManager.js";
import {MissionSystem} from "./missions/MissionSystem.js";
import {PoliceSystem} from "./police/PoliceSystem.js";
import {DayNightSystem} from "./weather/DayNightSystem.js";
import {WeatherSystem} from "./weather/WeatherSystem.js";
import {AudioManager} from "./audio/AudioManager.js";
import {MapSystem} from "./map/MapSystem.js";
import {UIManager} from "./ui/UIManager.js";
import {Menu} from "./ui/Menu.js";
import {Settings} from "./ui/Settings.js";

class Game{
 constructor(){this.paused=false;this.started=false;this.settings={quality:"Medium",traffic:65,npcs:70,volume:.7};this.ui=new UIManager(this);this.menu=new Menu(this);this.ui.bind();this.controller=new PlayerController();this.audio=new AudioManager();this.renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:"high-performance"});this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));this.renderer.setSize(innerWidth,innerHeight);this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.05;document.getElementById("game").appendChild(this.renderer.domElement);this.scene=new THREE.Scene();this.scene.background=new THREE.Color(0x8ab8c8);this.scene.fog=new THREE.FogExp2(0x8ab8c8,.0018);this.camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,1500);this.camera.position.set(0,5,50);addEventListener("resize",()=>this.resize());addEventListener("keydown",e=>this.keys(e))}
 async start(cont){this.menu.hide();this.ui.showHUD();this.audio.start();this.buildWorld();if(cont){const s=SaveSystem.load();if(s)this.restore(s)}this.started=true;this.loop=new GameLoop(dt=>this.update(dt),()=>this.render());this.loop.start();this.ui.toast("WELCOME TO VIZAG")}
 async buildWorld(){const progress=document.getElementById("load-progress"),status=document.getElementById("load-status");const set=(p,s)=>{progress.style.width=`${p}%`;status.textContent=s};set(10,"Loading world...");this.terrain=new Terrain(this.scene);set(25,"Loading coastline...");this.ocean=new Ocean(this.scene);set(38,"Loading roads...");this.roads=new Roads(this.scene);set(52,"Loading city blocks...");this.buildings=new Buildings(this.scene);set(66,"Loading player...");this.player=new Player(this.scene);this.cameraController=new CameraController(this.camera,this.player);set(76,"Loading vehicles...");const defs=await (await fetch("./data/vehicles.json")).json();this.vehicle=new Vehicle(this.scene,defs[0],[8,0,55]);this.traffic=new TrafficAI(this.scene,defs);set(86,"Loading NPCs...");this.npcs=new NPCManager(this.scene);set(92,"Loading missions...");const md=await (await fetch("./data/missions.json")).json();this.missions=new MissionSystem(this,md);this.police=new PoliceSystem(this);this.dayNight=new DayNightSystem(this.scene);this.weather=new WeatherSystem(this.scene);const locations=(await (await fetch("./data/locations.json")).json()).locations;this.map=new MapSystem(this,locations);this.streaming=new WorldStreaming(this);this.settingsUI=new Settings(this);set(100,"World ready");document.getElementById("loading").classList.add("hidden");this.ui.setMission(this.missions.current)}
 update(dt){if(!this.started||this.paused)return;this.dayNight.update(dt);this.weather.update(dt);this.ocean.update(dt);this.streaming.update();this.player.update(dt,this.controller.input,this);this.npcs.update(dt);this.traffic.update(dt,this.settings.traffic);if(this.player.onVehicle){
 const i=this.controller.input;
 this.vehicle.update(dt,{
   throttle:i.z < -.05 ? 1 : (i.z > .2 ? -1 : 0),
   steer:i.x,
   brake:i.z > .55 ? 1 : 0
 });
 this.player.position.copy(this.vehicle.position).add(new THREE.Vector3(0,.1,0));
 this.player.group.rotation.y=this.vehicle.heading;
}this.cameraController.update(dt,this.controller.mouse);this.controller.mouse.x=this.controller.mouse.y=0;this.missions.update();this.ui.setHealth(this.player.health);this.ui.setStamina(this.player.stamina);this.ui.setMoney(this.player.money);this.ui.setTime(this.dayNight.hour);this.ui.setWeather(this.weather.mode);this.ui.setVehicle(this.player.onVehicle);
 this.ui.setVehicleTelemetry(this.player.onVehicle ? this.vehicle.speed : 0, this.player.onVehicle ? this.vehicle.fuel : 0);
 this.ui.interaction(this.player.position.distanceTo(this.vehicle.position)<7)
}
 render(){this.renderer.render(this.scene,this.camera)}
 keys(e){if(e.repeat)return;if(e.code==="Escape"&&this.started){this.ui.pause(!this.paused)}if(e.code==="KeyM"&&this.started&&!this.paused){this.map?.open()}if(e.code==="KeyE"&&this.started&&!this.paused){if(this.player.position.distanceTo(this.vehicle.position)<7){this.player.onVehicle=this.player.onVehicle?null:this.vehicle;if(this.player.onVehicle)this.player.group.visible=false;else this.player.group.visible=true;this.ui.toast(this.player.onVehicle?"VEHICLE ENTERED":"VEHICLE EXITED")}}if(e.code==="Space"&&this.started&&!this.paused)this.player.jump();if(e.code==="KeyH"&&this.started&&!this.paused)this.police?.addCrime(1)}
 save(){if(!this.player)return;SaveSystem.save({position:this.player.position.toArray(),money:this.player.money,health:this.player.health,stamina:this.player.stamina,hour:this.dayNight.hour,weather:this.weather.mode,mission:this.missions.index})}
 restore(s){this.player.position.fromArray(s.position||[0,1,40]);this.player.money=s.money??2500;this.player.health=s.health??100;this.player.stamina=s.stamina??100;this.dayNight.hour=s.hour??8;this.missions.index=s.mission??0;this.missions.current=this.missions.main[this.missions.index]||null}
 exitToTitle(){this.save();location.reload()}
 resize(){this.camera.aspect=innerWidth/innerHeight;this.camera.updateProjectionMatrix();this.renderer.setSize(innerWidth,innerHeight)}
}
const g=new Game();
window.VizagGame=g;
setTimeout(()=>{document.getElementById("loading").classList.add("hidden")},800);
