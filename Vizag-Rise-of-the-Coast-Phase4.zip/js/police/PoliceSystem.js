
import * as THREE from "three";
import {NPC} from "../npc/NPC.js";
import {Vehicle} from "../vehicles/Vehicle.js";

export class PoliceSystem {
  constructor(scene, npcDefs, vehicleDefs) {
    this.scene=scene;
    this.npcDefs=npcDefs;
    this.vehicleDefs=vehicleDefs;
    this.wanted=0;
    this.cooldown=0;
    this.units=[];
    this.lastCrime=0;
  }

  addCrime(amount=1) {
    this.wanted=THREE.MathUtils.clamp(this.wanted+amount,0,5);
    this.lastCrime=performance.now()/1000;
  }

  clearWanted() {
    this.wanted=0;
    this.removeUnits();
  }

  removeUnits() {
    for(const u of this.units) this.scene.remove(u.group);
    this.units.length=0;
  }

  update(dt, playerPosition, playerSpeed=0) {
    const now=performance.now()/1000;
    if(this.wanted>0 && now-this.lastCrime>18) {
      this.wanted=Math.max(0,this.wanted-dt*.12);
      if(this.wanted<=.02) this.clearWanted();
    }

    const desired=Math.min(5,Math.ceil(this.wanted));
    while(this.units.length<desired) {
      const angle=Math.random()*Math.PI*2;
      const d=55+Math.random()*55;
      const def=this.npcDefs.find(x=>x.type==="police") || {type:"police",scale:1.05};
      const npc=new NPC(this.scene,def,[playerPosition.x+Math.cos(angle)*d,0,playerPosition.z+Math.sin(angle)*d]);
      npc.behavior.state="PATROL";
      this.units.push(npc);
    }

    for(const u of this.units) {
      const dx=playerPosition.x-u.position.x;
      const dz=playerPosition.z-u.position.z;
      const len=Math.hypot(dx,dz)||1;
      if(this.wanted>0.5){
        u.position.x+=dx/len*(1.6+this.wanted*.35)*dt;
        u.position.z+=dz/len*(1.6+this.wanted*.35)*dt;
        u.heading=Math.atan2(dx,dz);
        u.sync();
      }
    }

    if(this.wanted>0 && playerSpeed>32) this.lastCrime=now;
  }
}
