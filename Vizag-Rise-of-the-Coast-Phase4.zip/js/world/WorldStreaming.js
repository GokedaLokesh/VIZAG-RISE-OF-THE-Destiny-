export class WorldStreaming{
 constructor(game){this.game=game;this.zone="RK BEACH"}
 update(){const p=this.game.player?.position;if(!p)return;let z="RK BEACH";if(p.z>350)z="NAD / AIRPORT";else if(p.x>300)z="GAJUWAKA / PORT";else if(p.x<-250&&p.z<50)z="RUSHIKONDA";else if(p.z>120)z="CENTRAL VIZAG";else if(p.z<-180)z="YARADA / PORT";this.zone=z;this.game.ui.setZone(z)}
}