
export class NPCBehavior {
  constructor(npc) {
    this.npc = npc;
    this.state = "WANDER";
    this.target = null;
    this.timer = 0;
    this.speed = 1.0 + Math.random() * .65;
  }

  update(dt, worldTime = 12) {
    this.timer -= dt;

    if (this.timer <= 0) {
      const hour = worldTime % 24;
      if (hour >= 7 && hour < 10) this.state = Math.random() < .55 ? "WORK" : "WALK";
      else if (hour >= 17 && hour < 21) this.state = Math.random() < .5 ? "BEACH" : "SHOP";
      else if (hour >= 22 || hour < 6) this.state = "HOME";
      else this.state = Math.random() < .65 ? "WALK" : "SHOP";
      this.timer = 5 + Math.random() * 10;
    }

    const p = this.npc.position;
    if (this.state === "HOME") {
      this.npc.target = this.npc.home;
    } else if (this.state === "WORK") {
      this.npc.target = this.npc.work;
    } else if (this.state === "BEACH") {
      this.npc.target = {x: (Math.random()-.5)*250, z: -80 + Math.random()*120};
    } else if (this.state === "SHOP") {
      this.npc.target = {x: (Math.random()-.5)*350, z: 80 + Math.random()*220};
    } else {
      this.npc.target = {x: p.x + (Math.random()-.5)*80, z: p.z + (Math.random()-.5)*80};
    }

    if (this.npc.target) {
      const dx = this.npc.target.x - p.x;
      const dz = this.npc.target.z - p.z;
      const len = Math.hypot(dx,dz);
      if (len > 2) {
        p.x += dx/len * this.speed * dt;
        p.z += dz/len * this.speed * dt;
        this.npc.heading = Math.atan2(dx,dz);
      }
    }
  }
}
