
import * as THREE from "three";
import {NPCBehavior} from "./NPCBehavior.js";

export class NPC {
  constructor(scene, def, pos) {
    this.def = def;
    this.position = new THREE.Vector3(...pos);
    this.home = {x: this.position.x + (Math.random()-.5)*150, z: this.position.z + (Math.random()-.5)*150};
    this.work = {x: (Math.random()-.5)*350, z: 120 + Math.random()*280};
    this.heading = Math.random()*Math.PI*2;
    this.target = null;
    this.group = new THREE.Group();
    scene.add(this.group);
    this.behavior = new NPCBehavior(this);
    this.build();
  }

  build() {
    const skin = [0xc78b64,0xa96948,0x8f593e][Math.floor(Math.random()*3)];
    const clothes = [0x34516d,0x76523d,0x6d6b3f,0x8a3944,0x475b4e][Math.floor(Math.random()*5)];

    const body = new THREE.Mesh(
      new THREE.CylinderGeometry(.28,.34,.95,8),
      new THREE.MeshStandardMaterial({color:clothes,roughness:.9})
    );
    body.position.y=.65;
    body.castShadow=true;
    this.group.add(body);

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(.23,10,8),
      new THREE.MeshStandardMaterial({color:skin,roughness:.9})
    );
    head.position.y=1.35;
    head.castShadow=true;
    this.group.add(head);

    const legs = new THREE.Mesh(
      new THREE.BoxGeometry(.38,.65,.22),
      new THREE.MeshStandardMaterial({color:0x252b31,roughness:1})
    );
    legs.position.y=.05;
    legs.castShadow=true;
    this.group.add(legs);

    if (this.def.type === "police") {
      const cap = new THREE.Mesh(
        new THREE.CylinderGeometry(.25,.25,.08,10),
        new THREE.MeshStandardMaterial({color:0x1b2c45,roughness:.75})
      );
      cap.position.y=1.58;
      this.group.add(cap);
    }

    this.group.scale.setScalar(this.def.scale || 1);
    this.sync();
  }

  update(dt, time) {
    this.behavior.update(dt,time);
    this.sync();
  }

  sync() {
    this.group.position.copy(this.position);
    this.group.rotation.y=this.heading;
  }
}
