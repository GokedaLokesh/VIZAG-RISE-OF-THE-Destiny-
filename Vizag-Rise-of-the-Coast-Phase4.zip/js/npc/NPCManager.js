
import {NPC} from "./NPC.js";

export class NPCManager {
  constructor(scene, defs) {
    this.scene=scene;
    this.defs=defs;
    this.npcs=[];
    this.spawnTimer=0;
  }

  spawnOne() {
    const def=this.defs[Math.floor(Math.random()*this.defs.length)];
    const p={x:(Math.random()-.5)*700,z:-70+Math.random()*520};
    const npc=new NPC(this.scene,def,[p.x,0,p.z]);
    this.npcs.push(npc);
  }

  update(dt, density=60, gameTime=12) {
    const target=Math.floor(8+density*.22);
    this.spawnTimer-=dt;
    if(this.spawnTimer<=0 && this.npcs.length<target) {
      this.spawnOne();
      this.spawnTimer=Math.max(.3,1.6-density*.01);
    }

    for(let i=this.npcs.length-1;i>=0;i--){
      const n=this.npcs[i];
      n.update(dt,gameTime);
      if(Math.abs(n.position.x)>500 || n.position.z>650 || n.position.z<-230){
        this.scene.remove(n.group);
        this.npcs.splice(i,1);
      }
    }
  }

  clear() {
    for(const n of this.npcs) this.scene.remove(n.group);
    this.npcs.length=0;
  }
}
