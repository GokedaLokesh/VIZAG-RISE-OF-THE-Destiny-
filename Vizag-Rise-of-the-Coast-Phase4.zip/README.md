# VIZAG — RISE OF THE COAST

A modular Three.js/WebGL open-world browser game foundation inspired by Visakhapatnam (Vizag), Andhra Pradesh.


## Phase 4 implemented

NPC schedules, police gameplay and expanded mission content are now included.

## Phase 3 implemented

Advanced vehicles, lane-based traffic AI and touch controls are now included.

## Phase 2 implemented

- Expanded RK Beach sand/wet-sand zones
- Coastal promenade and railing
- Palm trees and beach furniture
- Larger fictionalized road network around the beach
- Street-light and traffic-signal props
- More varied city buildings and storefronts
- Landmark-style structures for beach hub, market and hill viewpoint
- Additional Phase 2 map locations
- Improved renderer color management, tone mapping and shadows

## Current playable foundation

- Cinematic title/loading screens
- Procedural Vizag-inspired coastal world
- RK Beach starting area
- Beach/ocean, roads, hills and procedural buildings
- Third-person player movement
- Sprint and jump
- Enter/exit a drivable vehicle
- Vehicle acceleration, braking, steering, fuel and HUD
- Pooled-style procedural traffic spawning/despawning
- NPC pedestrians with simple schedules/roaming state
- 24-hour day/night lighting
- Dynamic rain/storm/fog/cloudy states
- Mission framework and scalable JSON data
- Map and fast travel
- LocalStorage save/load
- Pause/settings/controls/credits
- GitHub Pages friendly, no backend
- No proprietary map imagery or copyrighted game assets

## Run

For GitHub Pages: upload the repository and enable Pages from the repository's main branch/root.

For local development, use a static server because ES modules and fetch() are blocked by many browsers when opened with `file://`.

Example:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`.

## Architecture

`js/core` — game loop, asset loading, save system  
`js/world` — terrain, ocean, roads, buildings, streaming zones  
`js/player` — player and camera  
`js/vehicles` — vehicles and traffic  
`js/npc` — NPCs  
`js/missions` — mission framework  
`js/police` — wanted system foundation  
`js/weather` — day/night and weather  
`js/audio` — Web Audio foundation  
`js/map` — map and fast travel  
`js/ui` — HUD, menus and settings  
`data` — scalable JSON data

## Expansion roadmap

1. Replace/provide GLB assets through `AssetManager`.
2. Add chunk-based asset streaming and LOD.
3. Add proper road graph and lane graph.
4. Upgrade traffic AI to lane-following/pathfinding.
5. Add animation clips and IK for NPCs.
6. Add interiors selectively.
7. Add 20 main + 30 side mission data.
8. Add police pursuit/roadblocks.
9. Add photo mode and Web Speech navigation.
10. Add mobile controls.
11. Add compressed textures and GPU profiling.
12. Expand zones toward a larger fictionalized Vizag-inspired world.

## Legal/asset note

This project uses fictionalized procedural geometry. Real place names are used as inspiration/reference points. Do not add Google Street View/Maps proprietary imagery, GTA assets, copyrighted characters, logos, music or unlicensed models. For OpenStreetMap-derived data, follow the applicable ODbL attribution and share-alike requirements before distributing derived database contents.

## License

MIT for the original code in this repository. Third-party libraries/assets remain under their own licenses.
